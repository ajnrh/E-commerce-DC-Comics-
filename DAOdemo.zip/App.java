package com.niit.daoexample;
import com.niit.daoexample.dao.ProductDAO;
import com.niit.daoexample.dao.ProductDAOImpl;
import com.niit.daoexample.model.Product;
public class App 
{
    public static void main( String[] args )
    {
    	ProductDAO productDAO = new ProductDAOImpl();

       
        for (Product product : productDAO.getAllProducts()) {
           System.out.println("Product: [ID : " + product.getProductId() + ", Name : " + product.getProductName() + " ]");
        }


        
        Product product=productDAO.getAllProducts().get(0);
        product.setProductName("60D");
        productDAO.updateProduct(product);

        
        productDAO.getProduct(0);
        System.out.println("Product: [RollNo : " + product.getProductId() + ", Name : " + product.getProductName() + " ]");	
    }
}
